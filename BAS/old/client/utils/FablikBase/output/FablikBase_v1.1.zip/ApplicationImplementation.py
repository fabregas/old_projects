from IOTypesStructure import *

import sql_queries as SQL
import traceback,sys,hashlib

from FablikSharedLib import FablikSharedLib

def parse_exception(e_obj, debug =False):
    if len(e_obj.args) == 2:
        (err_code, err_message) = e_obj.args
    else:
        (err_code,err_message) = (-1, str(e_obj))

    if debug:
        err_message += '\n' + '-'*80 + '\n'
        err_message += ''.join(apply(traceback.format_exception, sys.exc_info()))
        err_message += '-'*80 + '\n'

    return (err_code, err_message)

class MenuItem:
    def __init__(self, item_raw):
        self.id = item_raw[0]
        self.parent_id = item_raw[1]
        self.role_id = item_raw[2]
        self.form_id = item_raw[3]
        self.name = item_raw[4]
        self.help_description = item_raw[5]

    def update_checksum(self, hashed):
        hashed.update(str(self.id))
        hashed.update(str(self.parent_id))
        hashed.update(str(self.role_id))
        hashed.update(str(self.form_id))
        hashed.update(self.name)
        hashed.update(self.help_description)

class URL:
    def __init__(self, item_raw):
        self.id = item_raw[0]
        self.sid = item_raw[1]
        self.service_url = item_raw[2]
        self.description = description

    def update_checksum(self, hashed):
        hashed.update(str(self.id))
        hashed.update(self.sid)
        hashed.update(self.service_url)
        hashed.update(self.description)



def my_cmp(a, b):
    if a.id > b.id:
        return 1
    return -1

class FablikBaseImplementation:
    def start_routine(self, config):
        self.base_lib = FablikSharedLib.FablikBaseLibrary(config)

        self.syncronize_application(config)


    def syncronize_application(self, config):
        self.base_lib.syncronize(config)
        self.debug = config.get('DEBUG',0)

        #make cache
        self.menu_cache = []
        self.urls_cache = []
        self.menu_checksum = None
        self.urls_checksum = None

        menu = self.base_lib.getMenus()
        for item in menu:
            self.menu_cache.append(MenuItem(item))

        self.menu_cache.sort(cmp=my_cmp)
        md5 = hashlib.md5()
        for item in self.menu_cache:
            item.update_checksum(md5)

        self.menu_checksum = md5.hexdigest()

        urls = self.base_lib.getInterfaces()
        for item in urls:
            self.urls_cache.append(URL(item))

        self.urls_cache.sort(cmp=my_cmp)
        md5 = hashlib.md5()
        for item in self.urls_cache:
            item.update_checksum(md5)

        self.urls_checksum = md5.hexdigest()


    def stop_routine(self):
        self.database.close()

    def authenticate(self, request):
        err_code, err_message = (0, 'ok')
        session_id = ''
        roles_list = []

        try:
            user_id, session_id = self.base_lib.authenticate(request.login, request.password)

            roles = self.base_lib.getUserRoles(user_id)

            for item in roles:
                roles_list.append(role(sid=item[1]))
        except Exception, e_obj:
            err_code, err_message = parse_exception(e_obj, self.debug)

        return ResponseAuthenticate(ret_code=err_code, ret_message=err_message, session_id=session_id, roles_list=roles_list)


    def getMainMenu(self, request):
        menu_list = []
        for item in self.menu_cache:
            menu_list.append(menu_item(id=item.id, parent_id=item.parent_id, form_id=item.form_id, name=item.name, help=item.help_description))

        return ResponseGetMainMenu(ret_code=0, ret_message='ok', menu_list=menu_list)


    def getInterfaces(self, request):
        urls_list = []
        for item in self.urls_cache:
            urls_list.append(interface(sid=item.sid, service_url=item.service_url))

        return ResponseGetInterfaces(ret_code=0, ret_message='ok', interface_list=urls_list)


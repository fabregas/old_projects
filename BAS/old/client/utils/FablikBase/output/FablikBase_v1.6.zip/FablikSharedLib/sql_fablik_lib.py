
get_menu = 'SELECT id, parent_id, role_id, form_id, name, help_description, shortcut FROM bf_menu'
get_interfaces = 'SELECT id, sid, url, description FROM bf_applicationInterface'
get_password_hash = "SELECT password_checksum,id FROM bf_user WHERE login = '%s'"
get_session = "SELECT session_guid FROM bf_activesession WHERE user_id=%i"
get_session_by_id  = "SELECT user_id FROM bf_activesession WHERE session_guid='%s'"
modify_session = "UPDATE bf_activesession SET session_guid = '%s', session_start=current_timestamp WHERE user_id=%i"
insert_session = "INSERT INTO bf_activesession (session_guid, session_start, user_id) VALUES ('%s','%s',%i)"
get_user_roles = """
SELECT bf_role.id, bf_role.sid 
FROM bf_role, bf_user, bf_positionrole
WHERE bf_role.id = bf_positionrole.role_id
AND bf_positionrole.position_id = bf_user.position_id
AND (SELECT 1 from bf_departamentdisablerole 
    WHERE departament_id = bf_user.departament_id 
    AND role_id=bf_role.id) IS NULL
AND bf_user.id = %i
"""
get_audittype = "SELECT id, sid, audit_level FROM bf_audittype"
get_objectstype = "SELECT id, sid FROM bf_auditobject"
insert_audit = "INSERT INTO bf_audit (object_type,object_id,audit_type,datetime,audit_message) VALUES (%i,%i,%i,current_timestamp,'%s')"
get_departaments = "SELECT id,parent_id,name FROM bf_departament"
get_positions = "SELECT id,parent_id,name FROM bf_position"


import soaplib
from soaplib.serializers.clazz import ClassSerializer
import soaplib.serializers.primitive as simple
import soaplib.serializers.binary as binary

class role(ClassSerializer):
    sid = simple.String

class departament(ClassSerializer):
    id = simple.Integer
    parent_id = simple.Integer
    name = simple.String

class position(ClassSerializer):
    id = simple.Integer
    parent_id = simple.Integer
    name = simple.String

class menu_item(ClassSerializer):
    id = simple.Integer
    parent_id = simple.Integer
    form_id = simple.Integer
    name = simple.String
    help = simple.String
    shortcut = simple.String

class interface(ClassSerializer):
    sid = simple.String
    url = simple.String

class RequestAuthenticate(ClassSerializer):
    login = simple.String
    password = simple.String

class ResponseAuthenticate(ClassSerializer):
    ret_code = simple.Integer
    ret_message = simple.String
    session_id = simple.String
    roles_list = simple.Array(role)

class RequestGetMainMenu(ClassSerializer):
    session_id = simple.String
    checksum = simple.String

class ResponseGetMainMenu(ClassSerializer):
    ret_code = simple.Integer
    ret_message = simple.String
    menu_list = simple.Array(menu_item)

class RequestGetInterfaces(ClassSerializer):
    session_id = simple.String
    checksum = simple.String

class ResponseGetInterfaces(ClassSerializer):
    ret_code = simple.Integer
    ret_message = simple.String
    interface_list = simple.Array(interface)

class RequestGetDepartaments(ClassSerializer):
    session_id = simple.String
    root_departament_id = simple.String

class ResponseGetDepartaments(ClassSerializer):
    ret_code = simple.Integer
    ret_message = simple.String
    departament_list = simple.Array(departament)

class RequestGetPositions(ClassSerializer):
    session_id = simple.String
    root_position_id = simple.String

class ResponseGetPositions(ClassSerializer):
    ret_code = simple.Integer
    ret_message = simple.String
    position_list = simple.Array(position)


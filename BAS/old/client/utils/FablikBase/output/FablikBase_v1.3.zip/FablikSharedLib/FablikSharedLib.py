import sql_fablik_lib as SQL
import thread
from Database import Database
import hashlib,uuid

class FablikBaseLibrary:
    def __init__(self, config_map):
        self.__lock = thread.allocate_lock()

        DATABASE_STRING = config_map.get('FB_DATABASE_STRING',None)
        DATABASE_PSWD = config_map.get('FB_DATABASE_PASSWORD',None)

        if DATABASE_STRING is None or DATABASE_PSWD is None:
            raise Exception('FB_DATABASE_STRING and FB_DATABASE_PASSWORD must be set for this cluster')

        self.database = Database( DATABASE_STRING % DATABASE_PSWD )

        self.syncronize(config_map)


    def syncronize(self, config):
        self.__lock.acquire_lock()
        
        self.audit_level = config.get('AUDIT_LEVEL',5)

        audittypes= self.database.execute(SQL.get_audittype)

        self.audit_types = {}
        for atype in audittypes:
            self.audit_types[atype[1]] = (atype[0],atype[2])


        objectstypes= self.database.execute(SQL.get_objectstype)
        self.object_types = {}
        for atype in objectstypes:
            self.object_types[atype[1]] = atype[0]

        self.__lock.release_lock()


    def close(self):
        self.database.close()



    def authenticate(self, login, password):
        session_id = ''

        pwd = self.database.execute(SQL.get_password_hash % login)

        if not pwd:
            raise Exception(-1, 'User %s is not found!'%login)

        md5 = hashlib.md5()
        md5.update(password)
        pwd_hash = md5.hexdigest()

        if pwd_hash != pwd[0][0]:
            raise Exception (-2, 'Password is invalid')

        session_id = uuid.uuid4().hex
        
        user_id = pwd[0][1]
        session = self.database.execute(SQL.get_session % user_id)
        if session:
            self.database.modify(SQL.modify_session % (session_id, user_id))
            self.addAudit('user', user_id, 'repeatedLogin','')
        else:
            self.database.modify(SQL.insert_session % (session_id,user_id))

        return user_id, session_id


    def getUserRoles(self, user_id):
        roles = self.database.execute(SQL.get_user_roles % user_id)

        return roles


    def addAudit(self, auditObject, auditObjectID, auditType, message):
        self.__lock.acquire_lock()

        try:
            atype = self.audit_types.get(auditType, None)

            if atype is None:
                raise Exception("Audit type '%s' is not found" % auditType)

            (type_id, audit_level) = atype

            if self.audit_level < audit_level:
                return

            obj_type_id = self.object_types.get(auditObject, None)

            if obj_type_id is None:
                raise Exception("Audit object '%s' is not found" % auditObject)

            try:
                if auditObjectID is None:
                    auditObjectID = 0
                else:
                    auditObjectID = int(auditObjectID)
            except:
                raise Exception("Audit object ID id must be integer")


            try:
                message = str(message)
            except:
                raise Exception("Audit message be string")

            self.database.modify(SQL.insert_audit % (obj_type_id, auditObjectID, type_id, message))
        except Exception, msg:
            raise Exception(str(msg))
        finally:
            self.__lock.release_lock()

    def getMenus(self):
        menus = self.database.execute(SQL.get_menu)

        return menus

    def getInterfaces(self):
        urls = self.database.execute(SQL.get_interfaces)

        return urls

    def getDepartaments(self):
        departaments = self.database.execute(SQL.get_departaments)

        return departaments

    def getPositions(self):
        positions = self.database.execute(SQL.get_positions)

        return positions

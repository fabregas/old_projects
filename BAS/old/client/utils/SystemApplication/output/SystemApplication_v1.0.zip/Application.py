from IOTypesStructure import *
import ApplicationImplementation
import WSGI
import soaplib
import soaplib.service


class SystemApplication ( WSGI.Application ):
    def start(self, global_config={}, local_config={}):
        ''' init routine for web service'''
        self.__implementation = ApplicationImplementation.SystemApplicationImplementation()
        self.__implementation.start_routine(global_config, local_config)

    def stop(self):
        '''destroy routine for web service'''
        self.__implementation.stop_routine()

    @soaplib.service.soapmethod( RequestDeployApplication , _returns = ResponseDeployApplication(), _outVariableName='responseDeployApplication' )
    def DeployApplication(self, requestDeployApplication):
        return self.__implementation.DeployApplication(requestDeployApplication)


    @soaplib.service.soapmethod( RequestUndeployApplication , _returns = ResponseUndeployApplication(), _outVariableName='responseUndeployApplication' )
    def UndeployApplication(self, requestUndeployApplication):
        return self.__implementation.UndeployApplication(requestUndeployApplication)


    @soaplib.service.soapmethod( RequestStartApplication , _returns = ResponseStartApplication(), _outVariableName='responseStartApplication' )
    def StartApplication(self, requestStartApplication):
        return self.__implementation.StartApplication(requestStartApplication)


    @soaplib.service.soapmethod( RequestRestartApplication , _returns = ResponseRestartApplication(), _outVariableName='responseRestartApplication' )
    def RestartApplication(self, requestRestartApplication):
        return self.__implementation.RestartApplication(requestRestartApplication)


    @soaplib.service.soapmethod( RequestStopApplication , _returns = ResponseStopApplication(), _outVariableName='responseStopApplication' )
    def StopApplication(self, requestStopApplication):
        return self.__implementation.StopApplication(requestStopApplication)


    @soaplib.service.soapmethod( RequestGetNodeStatistic , _returns = ResponseGetNodeStatistic(), _outVariableName='responseGetNodeStatistic' )
    def GetNodeStatistic(self, requestGetNodeStatistic):
        return self.__implementation.GetNodeStatistic(requestGetNodeStatistic)


    @soaplib.service.soapmethod( RequestStartServerNode , _returns = ResponseStartServerNode(), _outVariableName='responseStartServerNode' )
    def StartServerNode(self, requestStartServerNode):
        return self.__implementation.StartServerNode(requestStartServerNode)


    @soaplib.service.soapmethod( RequestRestartServerNode , _returns = ResponseRestartServerNode(), _outVariableName='responseRestartServerNode' )
    def RestartServerNode(self, requestRestartServerNode):
        return self.__implementation.RestartServerNode(requestRestartServerNode)


    @soaplib.service.soapmethod( RequestStopServerNode , _returns = ResponseStopServerNode(), _outVariableName='responseStopServerNode' )
    def StopServerNode(self, requestStopServerNode):
        return self.__implementation.StopServerNode(requestStopServerNode)

